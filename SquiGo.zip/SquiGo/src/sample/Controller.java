package sample;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class Controller  implements Initializable {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Play_Button;

    @FXML
    private Button Exit_Button;

    void Exit(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Exit_Button.setOnAction(this::Exit);

    }
}
