package sample;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class Controller2 {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label Level_Label;

    @FXML
    private Canvas Canvas_Pane;

    @FXML
    private Button Exit_Button;

    @FXML
    private ProgressBar HP_Bar;

    @FXML
    void initialize() {


    }
}
